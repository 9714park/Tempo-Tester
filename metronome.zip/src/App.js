import React, { Component } from 'react';
import Metronome from './Components/Metronome'
import './App.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Metronome />
      </div>
    );
  }
}

export default App;
